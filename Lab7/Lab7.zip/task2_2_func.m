function y=task2_2_func(x)
y=x^9-522+exp(x);
end