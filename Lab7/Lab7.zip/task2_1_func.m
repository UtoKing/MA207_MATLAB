function y=task2_1_func(x)
y=3*x^2-exp(x);
end